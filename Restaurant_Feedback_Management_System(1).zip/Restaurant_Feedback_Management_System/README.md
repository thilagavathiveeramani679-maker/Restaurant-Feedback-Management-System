# Restaurant Feedback Management System

A DBMS laboratory mini-project built with Python Flask, SQLite, HTML, CSS and JavaScript.

## Features
- Dashboard with restaurant/customer/feedback statistics
- Add customer feedback
- View, search and filter feedback
- Delete feedback
- Restaurant management view
- Customer management view
- Reports and rating distribution
- SQLite relational database with primary keys and foreign keys
- Sample data is inserted automatically on first run

## Database Tables
1. restaurants
2. customers
3. feedback

## Relationship
restaurants (1) ---- (M) feedback (M) ---- (1) customers

## How to run in VS Code

### 1. Install Python
Make sure Python 3 is installed and the `python` command works in the VS Code terminal.

### 2. Open this folder
Open `Restaurant_Feedback_Management_System` in VS Code.

### 3. Create a virtual environment
Windows:
```powershell
python -m venv venv
venv\Scripts\activate
```

If PowerShell blocks activation, use:
```powershell
venv\Scripts\activate.bat
```

### 4. Install Flask
```powershell
pip install -r requirements.txt
```

### 5. Run
```powershell
python app.py
```

### 6. Open the webpage
Open the browser at:
http://127.0.0.1:5000

The SQLite database file `restaurant_feedback.db` is created automatically.

## Demo flow
1. Dashboard
2. Show Restaurants and Customers
3. Open Add Feedback
4. Add a new feedback record
5. Show it in Feedback Management
6. Search/filter feedback
7. Delete a feedback record
8. Open Reports to explain aggregate SQL queries

## DBMS concepts to explain
- Primary Key: restaurant_id, customer_id, feedback_id
- Foreign Keys: feedback.restaurant_id and feedback.customer_id
- One-to-many relationships
- JOIN queries
- GROUP BY and AVG/COUNT aggregate functions
- INSERT and DELETE operations
- Constraints such as rating CHECK(1 to 5) and email UNIQUE
