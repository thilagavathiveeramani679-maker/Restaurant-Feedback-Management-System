from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import sqlite3
from pathlib import Path
from datetime import datetime

app = Flask(__name__)
app.secret_key = "restaurant-feedback-demo-key"

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "restaurant_feedback.db"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS restaurants (
            restaurant_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            location TEXT NOT NULL,
            cuisine TEXT NOT NULL,
            contact TEXT
        );

        CREATE TABLE IF NOT EXISTS customers (
            customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            phone TEXT
        );

        CREATE TABLE IF NOT EXISTS feedback (
            feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
            restaurant_id INTEGER NOT NULL,
            customer_id INTEGER NOT NULL,
            rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
            comments TEXT NOT NULL,
            visit_date TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (restaurant_id) REFERENCES restaurants(restaurant_id) ON DELETE CASCADE,
            FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE
        );
    """)

    count = conn.execute("SELECT COUNT(*) AS c FROM restaurants").fetchone()["c"]
    if count == 0:
        restaurants = [
            ("Spice Garden", "Coimbatore", "South Indian", "9876543210"),
            ("Urban Bites", "Chennai", "Multi Cuisine", "9876501234"),
            ("The Pasta House", "Bengaluru", "Italian", "9123456780"),
        ]
        conn.executemany(
            "INSERT INTO restaurants(name, location, cuisine, contact) VALUES (?, ?, ?, ?)",
            restaurants
        )

        customers = [
            ("Arun Kumar", "arun@example.com", "9000000001"),
            ("Priya S", "priya@example.com", "9000000002"),
            ("Kavin Raj", "kavin@example.com", "9000000003"),
            ("Meena Devi", "meena@example.com", "9000000004"),
        ]
        conn.executemany(
            "INSERT INTO customers(name, email, phone) VALUES (?, ?, ?)",
            customers
        )

        restaurant_ids = [r["restaurant_id"] for r in conn.execute(
            "SELECT restaurant_id FROM restaurants ORDER BY restaurant_id"
        ).fetchall()]
        customer_ids = [c["customer_id"] for c in conn.execute(
            "SELECT customer_id FROM customers ORDER BY customer_id"
        ).fetchall()]

        feedback_rows = [
            (restaurant_ids[0], customer_ids[0], 5, "Excellent food and friendly service.", "2026-09-20"),
            (restaurant_ids[0], customer_ids[1], 4, "Tasty food. Waiting time was slightly high.", "2026-09-22"),
            (restaurant_ids[1], customer_ids[2], 3, "Good ambience but food can be improved.", "2026-09-25"),
            (restaurant_ids[1], customer_ids[3], 5, "Amazing experience. Will visit again!", "2026-09-28"),
            (restaurant_ids[2], customer_ids[0], 4, "Great pasta and clean restaurant.", "2026-09-30"),
        ]
        conn.executemany("""
            INSERT INTO feedback(restaurant_id, customer_id, rating, comments, visit_date)
            VALUES (?, ?, ?, ?, ?)
        """, feedback_rows)
    conn.commit()
    conn.close()

@app.route("/")
def index():
    conn = get_db()
    stats = {
        "restaurants": conn.execute("SELECT COUNT(*) c FROM restaurants").fetchone()["c"],
        "customers": conn.execute("SELECT COUNT(*) c FROM customers").fetchone()["c"],
        "feedback": conn.execute("SELECT COUNT(*) c FROM feedback").fetchone()["c"],
        "average": conn.execute("SELECT ROUND(COALESCE(AVG(rating),0),1) a FROM feedback").fetchone()["a"],
    }
    recent = conn.execute("""
        SELECT f.feedback_id, r.name AS restaurant, c.name AS customer,
               f.rating, f.comments, f.visit_date
        FROM feedback f
        JOIN restaurants r ON r.restaurant_id=f.restaurant_id
        JOIN customers c ON c.customer_id=f.customer_id
        ORDER BY f.feedback_id DESC LIMIT 6
    """).fetchall()
    conn.close()
    return render_template("index.html", stats=stats, recent=recent)

@app.route("/feedback")
def feedback_page():
    search = request.args.get("search", "").strip()
    rating = request.args.get("rating", "").strip()
    conn = get_db()
    query = """
        SELECT f.feedback_id, r.name AS restaurant, c.name AS customer,
               c.email, f.rating, f.comments, f.visit_date, f.created_at
        FROM feedback f
        JOIN restaurants r ON r.restaurant_id=f.restaurant_id
        JOIN customers c ON c.customer_id=f.customer_id
        WHERE 1=1
    """
    params = []
    if search:
        query += " AND (r.name LIKE ? OR c.name LIKE ? OR f.comments LIKE ?)"
        like = f"%{search}%"
        params += [like, like, like]
    if rating in {"1","2","3","4","5"}:
        query += " AND f.rating = ?"
        params.append(int(rating))
    query += " ORDER BY f.feedback_id DESC"
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return render_template("feedback.html", feedback=rows, search=search, rating=rating)

@app.route("/add-feedback", methods=["GET", "POST"])
def add_feedback():
    conn = get_db()
    restaurants = conn.execute("SELECT * FROM restaurants ORDER BY name").fetchall()
    customers = conn.execute("SELECT * FROM customers ORDER BY name").fetchall()

    if request.method == "POST":
        restaurant_id = request.form.get("restaurant_id")
        customer_id = request.form.get("customer_id")
        rating = request.form.get("rating")
        comments = request.form.get("comments", "").strip()
        visit_date = request.form.get("visit_date")

        if not all([restaurant_id, customer_id, rating, comments, visit_date]):
            flash("Please fill in all fields.", "error")
        else:
            try:
                rating_int = int(rating)
                if rating_int not in range(1, 6):
                    raise ValueError
                conn.execute("""
                    INSERT INTO feedback(restaurant_id, customer_id, rating, comments, visit_date)
                    VALUES (?, ?, ?, ?, ?)
                """, (restaurant_id, customer_id, rating_int, comments, visit_date))
                conn.commit()
                conn.close()
                flash("Feedback added successfully.", "success")
                return redirect(url_for("feedback_page"))
            except ValueError:
                flash("Rating must be between 1 and 5.", "error")

    conn.close()
    return render_template("add_feedback.html", restaurants=restaurants, customers=customers)

@app.route("/delete-feedback/<int:feedback_id>", methods=["POST"])
def delete_feedback(feedback_id):
    conn = get_db()
    conn.execute("DELETE FROM feedback WHERE feedback_id=?", (feedback_id,))
    conn.commit()
    conn.close()
    flash("Feedback deleted.", "success")
    return redirect(url_for("feedback_page"))

@app.route("/restaurants")
def restaurants_page():
    conn = get_db()
    restaurants = conn.execute("""
        SELECT r.*, COUNT(f.feedback_id) feedback_count,
               ROUND(COALESCE(AVG(f.rating),0),1) avg_rating
        FROM restaurants r
        LEFT JOIN feedback f ON f.restaurant_id=r.restaurant_id
        GROUP BY r.restaurant_id ORDER BY r.name
    """).fetchall()
    conn.close()
    return render_template("restaurants.html", restaurants=restaurants)

@app.route("/customers")
def customers_page():
    conn = get_db()
    customers = conn.execute("""
        SELECT c.*, COUNT(f.feedback_id) feedback_count
        FROM customers c
        LEFT JOIN feedback f ON f.customer_id=c.customer_id
        GROUP BY c.customer_id ORDER BY c.name
    """).fetchall()
    conn.close()
    return render_template("customers.html", customers=customers)

@app.route("/reports")
def reports():
    conn = get_db()
    by_restaurant = conn.execute("""
        SELECT r.name, COUNT(f.feedback_id) total,
               ROUND(COALESCE(AVG(f.rating),0),2) average
        FROM restaurants r
        LEFT JOIN feedback f ON f.restaurant_id=r.restaurant_id
        GROUP BY r.restaurant_id ORDER BY average DESC
    """).fetchall()
    distribution = conn.execute("""
        SELECT rating, COUNT(*) count FROM feedback
        GROUP BY rating ORDER BY rating
    """).fetchall()
    conn.close()
    return render_template("reports.html", by_restaurant=by_restaurant, distribution=distribution)

@app.route("/api/stats")
def api_stats():
    conn = get_db()
    data = conn.execute("""
        SELECT rating, COUNT(*) AS count
        FROM feedback GROUP BY rating ORDER BY rating
    """).fetchall()
    conn.close()
    return jsonify([dict(row) for row in data])

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
